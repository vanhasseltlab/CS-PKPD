####################################
########### CS PKPD model ##########
####### Processing script  #########
#######      Fitness      ##########
### Scenario 39 + 43 + 46  #########
##   Written by Linda Aulin       ##
####################################
###################################

library(dplyr)
library(tidyr)
library(forcats)
source("Plot_script.R")

memory.limit() 
memory.limit(24000)

Scenario_n <- 39

dat_path <- paste0("Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i))
  
  df_list[[i]] <- df_ii
  
}

df_39 <- bind_rows(df_list) %>% 
  left_join(Scenario_input, by =c("SIM_ID" = "ID")) %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n)


Scenario_n <- 43

dat_path <- paste0("Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i))
  
  df_list[[i]] <- df_ii
  
}


df_43 <- bind_rows(df_list) %>% 
  left_join(Scenario_input, by =c("SIM_ID" = "ID"))  %>% 
   mutate(S0 = 10^4) %>% 
   mutate(Scenario = Scenario_n)


Scenario_n <- 46

dat_path <- paste0("Results/Simulations/Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
   
   df_i <- file_list[i]
   df_ii<- readRDS(paste0(dat_path, "/",df_i))
   
   df_list[[i]] <- df_ii
   
}


df_46 <- bind_rows(df_list) %>% 
   left_join(Scenario_input, by =c("SIM_ID" = "ID"))  %>% 
   mutate(S0 = 10^4) %>% 
   mutate(Scenario = Scenario_n)



df_all<- df_46 %>% 
  bind_rows(df_39) %>%
  bind_rows(df_43) %>% 
  mutate(model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
  mutate(model = as.factor(model)) %>% 
  mutate(model = fct_relevel( model, c(      'Sequential',
                                       '3 day cycling', 
                                       '1 day cycling', 
                                       "Simultaneous")),
         Population = fct_relevel( Population, c('S', 
                                                 'RA',
                                                 'RB', 
                                                 'RARB'))) 

 res_line_fit_OVERALL_plot <- make_line_plot(df_all, type = "se coen")+
   scale_color_manual(values = c("#001201", "#008007", "#66ed6d"))+
   theme(axis.text = element_text(size = 12))+
   theme(axis.text.x = element_text(angle = 0))


 
 
  pdf( file = "FIG8_fit.pdf", height = 9, width = 12)
 res_line_fit_OVERALL_plot 
 dev.off()


 