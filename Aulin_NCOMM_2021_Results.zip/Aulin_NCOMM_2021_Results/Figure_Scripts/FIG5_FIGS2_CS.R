####################################
########### CS PKPD model ##########
####### Processing script  #########
#######      CS direction ##########
##### Scenario 39 + 40      ########
##   Written by Linda Aulin       ##
####################################
###################################

library(dplyr)
library(tidyr)
library(forcats)
source("Plot_script.R")

memory.limit() 
memory.limit(24000)

Scenario_n <- 39

dat_path <- paste0("Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i))
  
  df_list[[i]] <- df_ii
  
}

df_13_select <- bind_rows(df_list) %>% 
  left_join(Scenario_input, by =c("SIM_ID" = "ID")) %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n) %>% 
  filter(HILL_A == 3 & v_FIT == 1)


Scenario_n <- 40

dat_path <- paste0("Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i))
  
  df_list[[i]] <- df_ii
  
}



df_raw <- bind_rows(df_list) %>% 
  left_join(Scenario_input, by =c("SIM_ID" = "ID")) 

df<- df_raw %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n) %>% 
  filter(HILL_A == 3 & v_FIT == 1) %>% 
  bind_rows(df_13_select) %>% 
  mutate(model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
  mutate(model = as.factor(model)) %>% 
  mutate(model = fct_relevel( model, c('Sequential',
                                       '3 day cycling', 
                                       '1 day cycling', 
                                       "Simultaneous")),
         Population = fct_relevel( Population, c('S', 
                                                 'RA',
                                                 'RB', 
                                                 'RARB'))) %>% 
  filter(model %in% c("1 day cycling", "Simultaneous"))



####
res_bar_model_plot <- df %>% 
  filter(GMIN_A == -3 & CS_A != 0.1 & CS_B != 0.1) %>% 
  make_RES_bar_plot(R = "CS vs CS")+
  facet_grid( reorder(paste0("CS B ", CS_B, "%"), -CS_B) ~
                paste0("CS A ", CS_A, "%") )


pdf("FIG5_CS.pdf", height = 6)
res_bar_model_plot
dev.off()


res_bar_model_Static_plot <- df %>% 
  filter(GMIN_A == -1 & CS_A != 0.5 & CS_B != 0.5) %>% 
  make_RES_bar_plot(R = "CS vs CS")+
  facet_grid( reorder(paste0("CS B ", CS_B, "%"), -CS_B) ~
                paste0("CS A ", CS_A, "%") )

all_res_bar_model_plot <- df %>% 
  make_RES_bar_plot(R = "CS vs CS")+
  facet_grid(  Type_driver_A +
                 Type_eff_A +
                 reorder(paste0("CS B ", CS_B, "%"), -CS_B)              ~
                paste0("CS A ", CS_A, "%") )

pdf("FIGS2_CS.pdf", height = 12 , width = 12)
all_res_bar_model_plot
dev.off()

