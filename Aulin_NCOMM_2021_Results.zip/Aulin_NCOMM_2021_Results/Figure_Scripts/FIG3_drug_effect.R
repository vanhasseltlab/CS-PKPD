####################################
########### CS PKPD model ##########
####### Processing script  #########
#######      FIG 3         ##########
###          PKPD             #######
##   Written by Linda Aulin       ##
####################################
###################################




library(RxODE)


library(dplyr)
library(tidyr)
library(patchwork)
library(forcats)
source("Plot_script.R")


CB_col <- c("black", "#1E88E5", "#FFC107",  "#BE1908")
#col_order = CB_col
col_A <- "#72bfc5"
col_B <- "#6f30a0"




Scenario_n <- 39

dat_path <- paste0("Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i))
  
  df_list[[i]] <- df_ii
  
}

df_raw <- bind_rows(df_list) %>% 
  left_join(Scenario_input, by =c("SIM_ID" = "ID")) 

df<- df_raw %>% 
  mutate(S0 = 10^4) %>% 
  mutate(model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
  mutate(Scenario = Scenario_n,
         model = as.factor(model)) %>% 
  mutate(model = fct_relevel( model, c('Sequential',
                                       '3 day cycling', 
                                       '1 day cycling', 
                                       "Simultaneous")),
         Population = fct_relevel( Population, c('S', 
                                                 'RA',
                                                 'RB', 
                                                 'RARB'))) %>% 
distinct(time, model, .keep_all = T) %>% 
  group_by(model) %>% 
  mutate(ID = cur_group_id()) %>% 
ungroup() %>% 
  select(time, A,B, model, ID) %>% 
  filter(time <=145) 


PD_func <- function(conc_A = seq(0,10, 0.01), conc_B = seq(0,10, 0.01), Gmin = -1, Hill = 0.5, MIC_A = 1, MIC_B = 1){
  
  #Assume max growth = 1
  Gmax = 1
  
  eff <- (1 -
            ((1 - Gmin)*(conc_A/MIC_A)^Hill/((conc_A/MIC_A)^Hill - (Gmin/Gmax))) -  ((Gmax - Gmin)*(conc_B/MIC_B)^Hill/((conc_B/MIC_B)^Hill - (Gmin/Gmax))))
  
  df <- data.frame(conc_A = conc_A,
                   conc_B = conc_B,
                   eff = eff,
                   Gmin = Gmin,
                   Hill = Hill,
                   MIC_A = MIC_A,
                   MIC_B = MIC_B)
  return(df)
  
}


v_Gmin <- c(-1, -3)
v_HILL <- c(0.5, 3)
v_MIC_A <- c(0.1, 0.5, 1, 10)
v_MIC_B <- c(0.1, 0.5, 1, 10)
#v_MIC = 1



input <- expand.grid(Gmin = v_Gmin, Hill =  v_HILL, MIC_A = v_MIC_A, MIC_B = v_MIC_B) %>% 
  group_by(Hill, Gmin) %>% 
  mutate(id = cur_group_id()) %>% 
  mutate(Type_driver = ifelse(Hill == 0.5, "Time",
                              "Concentration"),
         Type_eff = ifelse(Gmin == -1, "Bacteriostatic","Bactericidal"))%>% 
  filter((((MIC_A<1 & MIC_B ==10 ) | (MIC_B<1 & MIC_A ==10) )) | (MIC_B >= 1 & MIC_A >= 1))

df_list <- list()

for(i in 1:length(input$id)){
  
  temp <- PD_func(conc_A = df$A, conc_B = df$B, Gmin = input$Gmin[i], Hill = input$Hill[i], MIC_A = input$MIC_A[i], MIC_B = input$MIC_B[i])
 temp$ID <- df$ID
 temp$time <- df$time 
     df_list[[i]]  <- temp
  
  
}



models <- df %>% 
  select(model, ID, time, conc_A = A, conc_B = B) %>% 
  distinct(model, ID, time)

#rm(df_raw)
# #rm(df_ii)
df_PD <- bind_rows(df_list)%>%
  left_join(input) %>%
  left_join(models)





PK_plot <- df_PD  %>% 
  distinct(model, time, .keep_all = T) %>% 
  filter(model != "Mono A") %>% 
  ggplot(aes(x = time))+
  geom_line(aes( y = conc_A, col = "A"), size = 1,  alpha = 0.5 )+
  geom_line(aes( y = conc_B, col = "B"), size = 1,  alpha = 0.5)+

  facet_grid(model~ .)+
  labs(x = "Time (h)",
       y = "Concentration (mg/L)",
       col = "Antibiotic")+ 
  theme_CS_clean_2()+
  scale_color_manual(values = c(col_A, col_B))+
  theme(legend.position = "bottom",
        strip.text = element_text(size = 20),
        axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1.1))




PD_plot_time<- df_PD  %>% 
  ggplot( aes( x = time,  y = eff))+
  geom_hline(yintercept = 0, alpha = 0.3, size =1)+
  geom_line(aes( col = Type_driver,
                 linetype = Type_eff),
            size = 1)+
  facet_grid(model ~ paste(MIC_A, "mg/L") + paste(MIC_B, "mg/L"))+
  labs(col = "Driver of effect",
       linetype = "Type of effect",
       x = "Time (h)",
       y   = "Antibiotic mediated growth inhibiton/killing")+
  scale_color_manual(values = c("red", "blue"))+
  theme_CS_clean_2()+
  theme(legend.position = "bottom",
        strip.text = element_text(size = 20),
        axis.text.x = element_text(angle = 45, hjust = 1, vjust = 1.1))


PK_plot + PD_plot_time +plot_layout(nrow = 1, widths = c(0.15, 1))

pdf("/PKPD_DR_v3.pdf", width = 25, height = 15)
PK_plot + PD_plot_time +plot_layout(nrow = 1, widths = c(0.3, 1))

dev.off()


PD_plot_time<- ggplot(df_A, aes( x = time, 
                               y = eff_tot))+
  geom_hline(yintercept = 0, alpha = 0.3, size =1)+
  geom_line(aes( col = Type_driver,
                 linetype = Type_eff),
            size = 1)+
  facet_grid(paste("MIC = ",MIC, "mg/L")~ model)+
  labs(col = "Driver of effect",
       linetype = "Type of effect",
       x = "Time (h)",
       y   = "Effect")+
  scale_color_manual(values = c("red", "blue"))+
  theme_CS_clean()+
  theme(axis.text.x = element_text(angle = 0))


pdf("PKPD.pdf", height = 12, width = 10)
PK_plot + PD_plot_time +plot_layout(nrow = 2, heights = c(0.2,1))
dev.off()




