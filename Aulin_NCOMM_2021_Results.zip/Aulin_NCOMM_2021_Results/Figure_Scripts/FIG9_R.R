####################################
########### CS PKPD model ##########
####### Processing script  #########
#######      Pre-existing R ########
### Scenario 39 + 47       #########
##   Written by Linda Aulin       ##
####################################
###################################

library(dplyr)
library(tidyr)
library(patchwork)
library(forcats)
source("Plot_script.R")


Scenario_n <- 39

dat_path <- paste0("Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i))
  
  df_list[[i]] <- df_ii
  
}

df_39 <- bind_rows(df_list) %>% 
  left_join(Scenario_input, by =c("SIM_ID" = "ID")) %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n,
         v_RA = 0,
         v_RB = 0) %>% 
  filter( v_FIT == 1)


Scenario_n <- 47

dat_path <- paste0("Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i))
  
  df_list[[i]] <- df_ii
  
}

df_raw <- bind_rows(df_list) %>% 
  left_join(Scenario_input, by =c("SIM_ID" = "ID")) 

df<- df_raw %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n) %>% 
  bind_rows(df_39 ) %>% 
  mutate(model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
  mutate(model = as.factor(model)) %>% 
  mutate(model = fct_relevel( model, c(                                  'Sequential',
                                       '3 day cycling', 
                                       '1 day cycling', 
                                       "Simultaneous")),
         Population = fct_relevel( Population, c('S', 
                                                 'RA',
                                                 'RB', 
                                                 'RARB')))



plot_df <- df %>% 
  distinct(time, model, SIM_ID, Population, .keep_all = T)


CB_col <- c("black", "#1E88E5", "#FFC107",  "#BE1908")
#col_order = CB_col
col_A <- "#72bfc5"
col_B <- "#6f30a0"


#Fig 2

plot_list <- list()
for(i in 1:length(unique(df$model))){
  M <- unique(df$model)[i]
  
  plot_list[[i]] <- df %>% 
    filter(v_FIT == 1 & CS_A == CS_B & model == M) %>% 
    make_RES_bar_plot( R = "CS")+
    facet_grid(Type_driver_A+
                 Type_eff_A ~ paste("RA", 100*v_RA, "%") + 
                 paste("RB", 100*v_RB, "%"))+
    ggtitle(M)
  
  print( plot_list[[i]])
  
}




pdf( file = "FIGS5_prex.pdf", height = 18, width = 17)
wrap_plots(plot_list)+plot_layout(guides = "collect")
dev.off()

pdf( file = "FIG10_preex.pdf", height = 10, width = 10)
print( plot_list[[3]])
dev.off()

