####################################
########### CS PKPD model ##########
####### Processing script  #########
#######      dose finding ##########
### Scenario 38            #########
##   Written by Linda Aulin       ##
####################################
###################################

library(dplyr)
library(tidyr)
library(forcats)
source("lot_script.R")

Scenario_n <- 38

dat_path <- paste0("Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i))
  
  df_list[[i]] <- df_ii
  
}




df_raw <- bind_rows(df_list) %>% 
  left_join(Scenario_input, by =c("SIM_ID" = "ID")) 

df<- df_raw %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n,
         model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
           mutate(model = as.factor(model)) %>% 
           mutate(
                  Population = fct_relevel( Population, c('S', 
                                                          'RA',
                                                          'RB', 
                                                          'RARB'))) %>%   
  mutate(Type_driver_A = ifelse(HILL_A == 0.5, "Time dependent",
                                "Concentration\ndependent"),
         Type_driver_B = ifelse(HILL_B == 0.5, "Time dependent",
                                "Concentration\ndependent"),
         Type_eff_A = ifelse(GMIN_A == -1, "Bacteriostatic","Bactericidal"),
         Type_eff_B = ifelse(GMIN_B == -1, "Bacteriostatic","Bactericidal"))
         


# 
CB_col <- c("black", "#1E88E5", "#FFC107",  "#BE1908")
col_A <- "#72bfc5"
col_B <- "#6f30a0"



PD_plot <- df %>% 
  distinct(Population, time, v_Css, HILL_A, GMIN_A, .keep_all = T) %>% 
  ggplot(aes( x = time))+
  geom_hline(mapping = aes(yintercept = S0, linetype = "Resistance cut-off"), size = 0.7)+
  geom_ribbon(aes(ymin = CFU_05,  ymax = CFU_95, fill = Population, 
                  group=  Population), alpha = 0.3)+
  geom_line( aes(y = CFU_MEDIAN,  col = Population, group= Population))+
  facet_grid(Type_driver_A +
               Type_eff_A ~ paste( "Css = ", v_Css))+
  scale_color_manual(values = CB_col, labels = c("WT", "RA", "RB", "RAB"))+
  scale_fill_manual(values = CB_col, labels = c("WT", "RA", "RB", "RAB"))+
  scale_linetype_manual(values = "dashed")+
  scale_y_log10(limits = c(0.01,10^10))+
  labs(x = "Time (hours)",
       y = "Bacteria (CFU/mL)",
       linetype = "",
       fill = "Subpopulation",
       col = "Subpopulation")+
  theme_CS()+
  theme(axis.text = element_text(size = 12))


pdf("FIG_S1.pdf", width = 15, height = 9)
PD_plot
dev.off()


