####################################
########### CS PKPD model ##########
####### Processing script  #########
#######      Drug type    ##########
### Scenario 39 + 41 + 49  #########
##   Written by Linda Aulin       ##
####################################
###################################

library(ggplot2)
library(dplyr)
library(tidyr)
library(patchwork)
library(forcats)
source("Plot_script.R")

memory.limit() 
memory.limit(24000)


Scenario_n <- 39

dat_path <- paste0("Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i))
  
  df_list[[i]] <- df_ii
  
}

df_13_select <- bind_rows(df_list) %>% 
  left_join(Scenario_input, by =c("SIM_ID" = "ID")) %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n) %>% 
  filter(model != "Mono A" & v_FIT == 1)




Scenario_n <- 49

dat_path <- paste0("Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i))
  
  df_list[[i]] <- df_ii
  
}

df_49 <- bind_rows(df_list) %>% 
  left_join(Scenario_input, by =c("SIM_ID" = "ID")) %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n) %>% 
  filter(model != "Mono A" & v_FIT == 1)


Scenario_n <- 41

dat_path <- paste0("Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i))
  
  df_list[[i]] <- df_ii
  
}

df_raw <- bind_rows(df_list) %>% 
  left_join(Scenario_input, by =c("SIM_ID" = "ID")) 

df<- df_raw %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n) %>% 
  bind_rows(df_13_select ) %>% 
  bind_rows(df_49 ) %>% 
  mutate(model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
  mutate(model = as.factor(model)) %>% 
  mutate(model = fct_relevel( model, c('Sequential',
                                       '3 day cycling', 
                                       '1 day cycling', 
                                       "Simultaneous")),
         Population = fct_relevel( Population, c('S', 
                                                 'RA',
                                                 'RB', 
                                                 'RARB'))) 



# plot_df <- df %>% 
#   distinct(time, model, SIM_ID, Population, .keep_all = T)


CB_col <- c("black", "#1E88E5", "#FFC107",  "#BE1908")
col_A <- "#72bfc5"
col_B <- "#6f30a0"



res_bar_CS_1DC_plot <- df %>% 
  filter(v_FIT == 1 & model == '1 day cycling') %>% 
  make_RES_bar_plot( R = "CS")+
  facet_grid(     reorder(paste("B:",Type_driver_B), HILL_B)+ 
                   reorder(Type_eff_B, -GMIN_B) ~
                    paste("A:", Type_driver_A)+ 
                   Type_eff_A )+
  ggtitle('1 day cycling')




res_bar_CS_seq_plot <- df %>% 
  filter(v_FIT == 1 & model == 'Sequential') %>% 
  make_RES_bar_plot( R = "CS")+
  facet_grid(     reorder(paste("B:",Type_driver_B), HILL_B)+ 
                    reorder(Type_eff_B, -GMIN_B) ~
                    paste("A:", Type_driver_A)+ 
                    Type_eff_A )+
  ggtitle('Sequential')
  
res_bar_CS_3DC_plot <- df %>% 
  filter(v_FIT == 1 & model == '3 day cycling') %>% 
  make_RES_bar_plot( R = "CS")+
  facet_grid(     reorder(paste("B:",Type_driver_B), HILL_B)+ 
                    reorder(Type_eff_B, -GMIN_B) ~
                    paste("A:", Type_driver_A)+ 
                    Type_eff_A )+
  ggtitle('3 day cycling')

res_bar_CS_1DC_plot <- df %>% 
  filter(v_FIT == 1 & model == '1 day cycling') %>% 
  make_RES_bar_plot( R = "CS")+
  facet_grid(     reorder(paste("B:",Type_driver_B), HILL_B)+ 
                    reorder(Type_eff_B, -GMIN_B) ~
                    paste("A:", Type_driver_A)+ 
                    Type_eff_A )+
  ggtitle('1 day cycling')


res_bar_CS_SIM_plot <- df %>% 
  filter(v_FIT == 1 & model == "Simultaneous") %>% 
 
  make_RES_bar_plot( R = "CS")+
  facet_grid(     reorder(paste("B:",Type_driver_B), HILL_B)+ 
                    reorder(Type_eff_B, -GMIN_B) ~
                    paste("A:", Type_driver_A)+ 
                    Type_eff_A )+
  ggtitle("Simultaneous")


res_bar_CS_seq_plot + res_bar_CS_3DC_plot + res_bar_CS_1DC_plot + res_bar_CS_SIM_plot +
  plot_layout(guides = "collect", ncol = 1)

pdf( file = "FIGS4_Drug_type.pdf", height = 11, width = 12)
res_bar_CS_seq_plot
res_bar_CS_3DC_plot
res_bar_CS_1DC_plot
res_bar_CS_SIM_plot


dev.off()

pdf( file = "FIGS4_Drug_type_collect.pdf", height = 22, width = 22)
res_bar_CS_seq_plot + res_bar_CS_3DC_plot + res_bar_CS_1DC_plot + res_bar_CS_SIM_plot +
  plot_layout(guides = "collect", ncol = 2)


dev.off()


res_bar_CS_1DC_plot_FIG <- df %>% 
  filter(v_FIT == 1 & model == '1 day cycling') %>% 
  make_RES_bar_plot( R = "CS")+
  facet_grid(     reorder(Type_driver_B, HILL_B)+ 
                    reorder(Type_eff_B, -GMIN_B) ~
                    Type_driver_A+ 
                    Type_eff_A )+
  ggtitle('1 day cycling')



pdf( file = "FIG6_Drug_type.pdf", height = 11, width = 12)

res_bar_CS_1DC_plot_FIG

dev.off()

