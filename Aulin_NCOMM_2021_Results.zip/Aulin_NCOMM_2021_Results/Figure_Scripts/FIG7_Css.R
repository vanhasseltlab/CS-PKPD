####################################
########### CS PKPD model ##########
####### Processing script  #########
#######      Css          ##########
### Scenario 42            #########
##   Written by Linda Aulin       ##
####################################
###################################

########
library(dplyr)
library(tidyr)
library(forcats)

memory.limit() 
memory.limit(24000)
source("Plot_script.R")

Scenario_n <-42

dat_path <- paste0("Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i))
  
  df_list[[i]] <- df_ii
  
}




df_raw <- bind_rows(df_list) %>% 
  left_join(Scenario_input, by =c("SIM_ID" = "ID")) 

df<- df_raw %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n,
         model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
           mutate(model = as.factor(model)) %>% 
           mutate(
             model = fct_relevel( model, c(
                                                'Sequential',
                                                '3 day cycling',
                                                '1 day cycling',
                                                "Simultaneous")),
                  Population = fct_relevel( Population, c('S', 
                                                          'RA',
                                                          'RB', 
                                                          'RARB'))) 

# 
CB_col <- c("black", "#1E88E5", "#FFC107",  "#BE1908")
col_order = c( "#1E88E5", "#FFC107",  "#BE1908")
col_A <- "#72bfc5"
col_B <- "#6f30a0"



plot_dat <- df %>% 
  filter(time == 336 & v_Css < 5) %>% 
  Any_fun() %>% 
  distinct(model, Population, SIM_ID, .keep_all = T)

 
css_overall_plot<- plot_dat %>% 
  filter(Population == "Any" & model != "Mono A" & v_Css > 1 ) %>% 
  filter(model != "Mono A") %>% 
  mutate(CS = 100 - CS_A*100) %>% 
  ggplot(aes( x =  v_Css,
              y = R_Dev*100/n))  +
  
  geom_line(aes(group = CS, linetype = paste0(CS, "%"),
                col = paste0(CS, "%")), size = 1, alpha = 0.6)+
  geom_linerange(aes(ymin = R_Dev*100/n - SE*100, 
                     ymax = R_Dev*100/n + SE*100, 
                     group = CS))+
  facet_grid(Type_driver_A+ 
               Type_eff_A ~
               model)+
  
  ylim(0, 100)+
  labs(x = expression(paste(C[ss], "x ", MIC[WT])),
       y = "Probability of resistance (%)",
       linetype = "Magnitude of CS\nMIC reduction",
       col= "Magnitude of CS\nMIC reduction") +
  theme_CS_clean_2()+
  theme(axis.text.x = element_text(angle = 0),
        axis.text = element_text( size = 12))+

  scale_color_manual(values = c("#001201", "#008007", "#66ed6d"))#+
 


pdf( file = "FIG7_Css.pdf", height = 9, width = 12)
css_overall_plot
dev.off()


df_select<- df %>% 
  filter(time == 336)
plot_list <- list()
for(i in 1:length(unique(df_select$model))) {
  
  M <- unique(df_select$model)[i]
  
  df_plot_S <- Any_fun(df_select) %>% 
    filter(model == M) %>% 
    mutate(v_FIT = 100 - v_FIT*100,
           CS = 100 - CS_A*100) 
  
  res_plot<- ggplot(df_plot_S[df_plot_S$Population != "Any",], 
                    aes( x = paste0(CS, "%"), 
                         y = R_Dev*100/n,
                         fill = Population))  +
    geom_col(data = df_plot_S[df_plot_S$Population == "Any",],  
             alpha = 0.7, width = 0.6)+
    geom_col(aes(group = Population),
             col = "black", position = "dodge", width = 0.6)+
    geom_linerange(data = df_plot_S[df_plot_S$Population == "Any",], 
                   aes(ymin = p*100 - SE*100,
                       ymax = p*100 +SE*100))+
    geom_linerange(aes(ymin = p*100 - SE*100,
                       ymax = p*100 +SE*100, 
                       group = Population),
                   col = "black", position = position_dodge(width = 0.6))+
    facet_grid(Type_driver_A+
                 Type_eff_A   ~ 
                 paste("Css =",v_Css))+
    ylim(0, 100)+
    labs(x = "Magnitude of CS MIC reduction",
         y = "Probability (%)",
         fill = "Subpopulation")+
    ggtitle(M)+
    scale_fill_manual(values = c(   "black", col_order, "gray") , drop = F)+
    theme_CS_clean()
  
  plot_list[[i]] <-   res_plot
  
}




pdf( file = "FIGS4_Css.pdf", height = 10, width = 15)

  print(plot_list)

dev.off()
