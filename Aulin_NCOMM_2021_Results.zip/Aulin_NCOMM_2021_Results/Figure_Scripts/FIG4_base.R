####################################
# Processing CS simulation data ####
########  Scenario 13  #############
########  Figure 2A-C  #############
########                 ###########
######     Linda Aulin    ##########
######### 2020-12-02 ###############
####################################

library(dplyr)
library(tidyr)
library(patchwork)
library(forcats)
source("Plot_script.R")

Scenario_n <- 39

dat_path <- paste0("Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i))
  
  df_list[[i]] <- df_ii
  
}

df_raw <- bind_rows(df_list) %>% 
  left_join(Scenario_input, by =c("SIM_ID" = "ID")) 

df<- df_raw %>% 
  mutate(S0 = 10^4) %>% 
  mutate(model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
  mutate(Scenario = Scenario_n,
         model = as.factor(model)) %>% 
  mutate(model = fct_relevel( model, c('Sequential',
                                       '3 day cycling', 
                                       '1 day cycling', 
                                       "Simultaneous")),
         Population = fct_relevel( Population, c('S', 
                                            'RA',
                                            'RB', 
                                            'RARB')))



plot_df <- df %>% 
  distinct(time, model, SIM_ID, Population, .keep_all = T)


CB_col <- c("black", "#1E88E5", "#FFC107",  "#BE1908")
col_A <- "#72bfc5"
col_B <- "#6f30a0"


#Fig 2

res_bar_CS_plot <- df %>% 
  filter(v_FIT == 1 ) %>% 
  make_RES_bar_plot( R = "CS")

pdf( file = "FIG4_base.pdf", height = 10, width = 11)
res_bar_CS_plot
dev.off()
