####################################
########### CS PKPD model ##########
####### Processing script  #########
#######      Drug type    ##########
### Scenario 39 + 48       #########
##   Written by Linda Aulin       ##
####################################
###################################
library(dplyr)
library(tidyr)
library(forcats)
source("Scripts/CS_model/Figures/Plot_script_v7.R")
memory.limit() 
memory.limit(24000)

col_order <- c("black", "#1E88E5", "#FFC107",  "#BE1908")

Scenario_n <- 39

dat_path <- paste0("Results/Simulations/Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i))
  
  df_list[[i]] <- df_ii
  
}

df_39 <- bind_rows(df_list) %>% 
  left_join(Scenario_input, by =c("SIM_ID" = "ID")) %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n) %>% 
  filter(v_FIT == 1) 






Scenario_n <- 48

dat_path <- paste0("Results/Simulations/Scenario_", Scenario_n)
file_list <-list.files(dat_path, pattern = "sim")
Scenario_input <- readRDS(paste0(dat_path, "/","Scenario_", Scenario_n , "_input.rds"))

df_list <- list()
for(i in 1:length(file_list)) {
  
  df_i <- file_list[i]
  df_ii<- readRDS(paste0(dat_path, "/",df_i))
  
  df_list[[i]] <- df_ii
  
}


df_raw <- bind_rows(df_list) %>% 
  left_join(Scenario_input, by =c("SIM_ID" = "ID")) 

df<- df_raw %>% 
  mutate(S0 = 10^4) %>% 
  mutate(Scenario = Scenario_n) %>% 
  bind_rows(df_39) %>% 
  mutate(model = ifelse(model == "Combination", "Simultaneous", model)) %>% 
  mutate(model = as.factor(model)) %>% 
  mutate(model = fct_relevel( model, c('Sequential',
                                       '3 day cycling', 
                                       '1 day cycling', 
                                       "Simultaneous")),
         Population = fct_relevel( Population, c('S', 
                                                 'RA',
                                                 'RB', 
                                                 'RARB'))) 





plot_df <- df %>% 
  distinct(time, model, SIM_ID, Population, .keep_all = T, Scenario)


CB_col <- c("black", "#1E88E5", "#FFC107",  "#BE1908")
col_A <- "#72bfc5"
col_B <- "#6f30a0"


plot_dat <- df %>% 
  filter(time == 336) %>% 
  Any_fun() %>% 
  distinct(model, Population, SIM_ID,  Scenario, .keep_all = T)



###### range = -9 to -6


u_overall_range_9_6_plot<- plot_dat %>% 
  filter(Population == "Any" & model != "Mono A" & U_1 %in% c( 10^-9, 10^-8, 10^-7, 10^-6)) %>% 
  mutate(CS = 100 - CS_A*100) %>% 
  ggplot(aes( x =  log10(U_1),
              y = R_Dev*100/n))  +
  
  geom_line(aes(group = CS, linetype = paste0(CS, "%"),
                col = paste0(CS, "%")), size = 1, alpha = 0.7)+
  geom_linerange(aes(ymin = R_Dev*100/n - SE*100, 
                     ymax = R_Dev*100/n + SE*100, 
                     group = CS))+
  facet_grid(Type_driver_A+ 
               Type_eff_A ~
               model)+
  
  ylim(0, 100)+
  labs(x = "log10 mutation rate (mut/bp/h)",
       y = "Probability of resistance (%)",
       linetype = "Magnitude of CS\nMIC reduction",
       col= "Magnitude of CS\nMIC reduction") +
  #  ggtitle("Overall resistance")+
  theme_CS_clean_2()+
  theme(axis.text.x = element_text(angle = 0),
        axis.text = element_text( size = 12))+
  # scale_color_manual(values = c("black", "green4", "green2"))
  scale_color_manual(values = c("#001201", "#008007", "#66ed6d"))

pdf( file = "Results/Nat_comm/Figures/FIG10_u_range9-6.pdf", height = 10, width = 15)
u_overall_range_9_6_plot
dev.off()



