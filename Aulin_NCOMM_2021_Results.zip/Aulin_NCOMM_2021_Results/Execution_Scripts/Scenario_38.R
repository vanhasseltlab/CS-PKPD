# Load packages

library(doParallel)
library(doRNG)
library(RxODE)
library(dplyr)
library(tidyr)
library(ggplot2)


# Parallellization



wd <- #Specify working directory

nodelist<-rep("localhost",47) # 64 cores
cl<-makePSOCKcluster(nodelist) 
registerDoParallel(cl)
clusterCall(cl, function(x) .libPaths(x), .libPaths())

clusterEvalQ(cl, setwd(wd)) # set work dir correctly to each cluster instance

#Prevent CPU overload 
setRxThreads(threads = 1)


source("CS_model_function.R")


###
# Scenario 38
# Dose finding for mono A
###########

Scenario_n <- 38

#Create folder
dir.create(paste0("Scenario_",Scenario_n))

#define input 

n = 500
v_CS_A  <- 1
v_CS_B  <- 1
v_FIT <- 1
v_HILL<- c(0.5, 3)
v_Gmin <- c(-1, -3)
v_RA <- 0
v_RB <- 0
v_Css <- c(0.5, 1, 1.5, 2, 2.5, 3, 3.5, 4) 


input_all <- expand_grid(v_HILL, v_CS_A, v_CS_B, v_FIT, v_Gmin, v_RA, v_RB, v_Css) %>% 
  filter( v_CS_A == v_CS_B) %>% 
  arrange(desc(v_FIT), desc(v_CS_A), desc(v_CS_B), v_HILL) %>% 
  mutate(ID = row_number()) %>% 
  as.data.frame()

saveRDS(input_all, file = paste0("Scenario_", Scenario_n, "/" ,"Scenario_", Scenario_n, "_input.rds" ))

select_ID <- 1:length(input_all$ID)

for(i in 1:length(select_ID )){
  
  id_i <- select_ID[i] 
  
  input <- input_all %>% 
    filter(ID %in% select_ID)
  
  sim <- CS_model(  v_Models = "Mono A",
                   
                   FIT     =  input$v_FIT[i],
                   CS_A    =  input$v_CS_A[i],
                   CS_B    =  input$v_CS_B[i],
                   HILL_A	=  input$v_HILL[i],
                   HILL_B	=  input$v_HILL[i], 
                   Gmin_A	=  input$v_Gmin[i],
                   Gmin_B	=  input$v_Gmin[i], 
                   u_1 = 10^-9, 
                   u_2 = 10^-9,
                   eB0  = 4,
                   F_Css_MIC = input$v_Css[i],
                   RA0 = input$v_RA[i],
                   RB0 = input$v_RB[i],
                   #t_half = input$v_thalf[i], 
                   Bmax = 8,
                   V    = 5000,
                   n    = n,
                   ST   = 24*14) %>% 
    mutate(SIM_ID = id_i,
           n = n)
  
  saveRDS(sim, file = paste0("Scenario_", Scenario_n, "/" ,"Scenario_", Scenario_n, "_sim_",id_i, "_n",n, "_", Sys.Date(), ".rds" ))
  
}

stopCluster(cl)

