#############################
### Plot function script ####
require(ggplot2)
require(dplyr)

#General theme
theme_CS <- function () { 
  theme_bw() %+replace% 
    theme(text = element_text(size = 20),
          plot.margin=unit(c(3,3,3,3),"mm")
    )
}

theme_CS_clean <- function () { 
  theme_bw() %+replace% 
    theme(text = element_text(size = 20),
          axis.text = element_text(size = 18),
          plot.margin=unit(c(3,3,3,3),"mm"),
          axis.text.x = element_text(angle = 90, hjust = 1),
          panel.grid.minor = element_blank(),
          panel.grid.major = element_line(colour = "#f7f7f7") #element_blank()
    )
}


theme_CS_clean_2 <- function () { 
  theme_bw() %+replace% 
    theme(text = element_text(size = 20),
          axis.text = element_text(size = 18),
          plot.margin=unit(c(3,3,3,3),"mm"),
          #axis.text.x = element_text(angle = 90, hjust = 1),
          panel.grid.minor = element_blank(),
          panel.grid.major = element_line(colour = "#f7f7f7") #element_blank()
    )
}
#
#Function to calaculat Rany

Any_fun <- function(df){
  
  df_plot <- df %>% 
    distinct(Population, SIM_ID, Scenario, model, .keep_all = T)%>% 
    mutate(Population = fct_relevel( Population, c('S',
                                                   'RA',
                                                   'RB', 
                                                   'RARB' 
    ))) 
  
  
  levels(df_plot$Population) <- c(levels(df_plot$Population)[1:3] ,
                                  'RAB', 
                                  "Any")
  
  df_plot_Any <- df %>% 
    filter(Population != "S") %>% 
    group_by(time, model, Scenario, SIM_ID, day_id) %>% 
    mutate(R_Day_CFU_n = ifelse(any(Day_CFU >= S0, na.rm = T), 1, 0)) %>% 
    distinct(time, model, Scenario, SIM_ID, day_id, .keep_all = T) %>% 
    ungroup() %>% 
    group_by(time, model, Scenario, SIM_ID) %>% 
    mutate(R_Dev = sum(R_Day_CFU_n)) %>%    
    distinct( model, Scenario, SIM_ID, .keep_all = T) 
  
  levels(df_plot_Any$Population) <-  c(rep("Any", 4))
  
  df_plot_2 <- df_plot %>% 
    bind_rows(df_plot_Any) %>% 
    mutate(Population = fct_relevel(Population, c('S',
                                                  'RA',
                                                  'RB', 
                                                  'RAB', 
                                                  "Any"
    ))) %>% 
    mutate(p = R_Dev/n) %>% 
    mutate(
      CI = 1.96*sqrt(p*(1-p)/n),
      SE = sqrt(p*(1-p)/n))%>%   
    mutate(Type_driver_A = ifelse(HILL_A == 0.5, "Time dependent",
                                  "Concentration\ndependent"),
           Type_driver_B = ifelse(HILL_B == 0.5, "Time dependent",
                                  "Concentration\ndependent"),
           Type_eff_A = ifelse(GMIN_A == -1, "Bacteriostatic","Bactericidal"),
           Type_eff_B = ifelse(GMIN_B == -1, "Bacteriostatic","Bactericidal"))
  
  
  levels(df_plot_2$Population)[1] <- "WT"
  return(df_plot_2)
  
}



#PD dynamic plot by model (dosing regimen), facetted by PD paramters

make_PD_plot <- function(df, col_order = c("#70ad47",  "#001ac0", "#ed7c31","#ff0000")){
  df_plot<- df %>% 
    distinct(time, Population, model, Scenario, SIM_ID, .keep_all = T)
  
  
  models <- unique(df_plot$model)
  
  
  plot_list <- list()
  for(i in 1:length(models)){
    
 
    
    M <-  models[i]
    #col_order <- c("#70ad47",  "#001ac0", "#ed7c31","#ff0000")
    
    
    plot_PD<- ggplot(df_plot[df_plot$model == M,], aes(x = time))+
      geom_hline(mapping = aes(yintercept = S0, linetype = "Resistance cut-off"), size = 0.7)+
      geom_ribbon(aes(ymin = CFU_05,  ymax = CFU_95, fill = Population, 
                      group=  Population), alpha = 0.3)+
      geom_line( aes(y = CFU_MEDIAN,  col = Population, group= Population))+
      facet_grid(paste("Gmin A =", GMIN_A) + 
                   paste("Gmin B =" , GMIN_B) +paste("Hill A = ", HILL_A) + 
                   paste("HIll B =", HILL_B) ~ paste("FIT", v_FIT)+ paste("CS B", CS_B)+ paste("CS A", CS_A))+
      scale_color_manual(values = col_order, labels = c("WT", "MA", "MB", "MAB"))+
      scale_fill_manual(values = col_order, labels = c("WT", "MA", "MB", "MAB"))+
      scale_linetype_manual(values = "dashed")+
      scale_y_log10(limits = c(0.01,10^10))+
      ggtitle(M)+
      labs(x = "Time (hours)",
           y = "Bacteria (CFU/mL)",
           linetype = "",
           fill = "Subpopulation",
           col = "Subpopulation")+
      theme_CS() 
    
    
    plot_list[[i]] <- plot_PD
  }
  
  return(plot_list)
}



make_PD_ID_plot <- function(df, col_order = c("#70ad47",  "#001ac0", "#ed7c31","#ff0000")){
  df_plot<- df %>% 
    distinct(time, Population, model, Scenario, SIM_ID, .keep_all = T)
  
  
  models <- unique(df_plot$model)
  
  
  plot_list <- list()
  for(i in 1:length(models)){
    
    
    
    M <-  models[i]
    #col_order <- c("#70ad47",  "#001ac0", "#ed7c31","#ff0000")
    
    
    plot_PD<- ggplot(df_plot[df_plot$model == M,], aes(x = time))+
      geom_hline(mapping = aes(yintercept = S0, linetype = "Resistance cut-off"), size = 0.7)+
      geom_ribbon(aes(ymin = CFU_05,  ymax = CFU_95, fill = Population, 
                      group=  Population), alpha = 0.3)+
      geom_line( aes(y = CFU_MEDIAN,  col = Population, group= Population))+
      facet_wrap(~interaction(U,SIM_ID))+
      scale_color_manual(values = col_order, labels = c("WT", "MA", "MB", "MAB"))+
      scale_fill_manual(values = col_order, labels = c("WT", "MA", "MB", "MAB"))+
      scale_linetype_manual(values = "dashed")+
      scale_y_log10(limits = c(0.01,10^10))+
      ggtitle(M)+
      labs(x = "Time (hours)",
           y = "Bacteria (CFU/mL)",
           linetype = "",
           fill = "Subpopulation",
           col = "Subpopulation")+
      theme_CS() 
    
    
    plot_list[[i]] <- plot_PD
  }
  
  return(plot_list)
}


####


make_RES_bar_plot <- function(df, R = "model", col_order = c( "#1E88E5", "#FFC107",  "#BE1908")) {
  
  
  
  if(R == "model") {
  
    
    df_select<- df %>% 
      filter(time == 336 & Population != "S")
    
    
    df_plot <- Any_fun(df_select)
    
    
    
    res_plot<- ggplot(df_plot[df_plot$Population != "Any",], 
                      aes( x = model, 
                           y = R_Dev*100/n,
                           fill = Population))  +
      geom_col(data = df_plot[df_plot$Population == "Any",],  
               alpha = 0.7, width = 0.6)+
      geom_col(aes(group = Population),
               col = "black", position = "dodge", width = 0.6)+
      geom_linerange(data = df_plot[df_plot$Population == "Any",], 
                     aes(ymin = p*100 - SE*100,
                         ymax = p*100 +SE*100))+
      geom_linerange(aes(ymin = p*100 - SE*100,
                        ymax = p*100 +SE*100, 
                        group = Population),
               col = "black", position = position_dodge(width = 0.6))+
      # facet_grid(paste("Hill =", HILL_A)+
      #              paste("Gmin =", GMIN_A)  ~ 
      #              paste("FIT", v_FIT)+ paste("CS B", CS_B)+ paste("CS A", CS_A))+
      facet_grid(Type_driver_A+
                   Type_eff_A  ~ 
                   paste("FIT", v_FIT)+ paste("CS B", CS_B)+ paste("CS A", CS_A))+
      ylim(0, 100)+
      
      labs(x = "Dosing regimen",
           y = "Probability of resistance (%)",
           fill = "Resistant\nsubpopulation")+
      scale_fill_manual(values = c( "gray", col_order) , drop = F,labels = c("Any",
                                                                             expression(R[A]),
                                                                             expression(R[B]),
                                                                             expression(R[AB])))+
      theme_CS_clean()
    
    return(res_plot)
  
  

  } else if(R == "FIT"){
    
    
    df_select<- df %>% 
      filter(time == 336 & Population != "S" & CS_A == 1 & CS_B == 1)
    
    
    df_plot <- Any_fun(df_select)
    

    res_plot<- ggplot(df_plot[df_plot$Population != "Any",],
                      aes( x = paste("Fit =", v_FIT),
                           y = R_Dev*100/n,
                           fill = Population))  +
      geom_col(data = df_plot[df_plot$Population == "Any",],  
               alpha = 0.7, width = 0.6)+
      geom_col(aes(group = Population),
               col = "black", position = "dodge", width = 0.6)+
      geom_linerange(data = df_plot[df_plot$Population == "Any",], 
                     aes(ymin = p*100 - SE*100,
                         ymax = p*100 +SE*100))+
      geom_linerange(aes(ymin = p*100 - SE*100,
                         ymax = p*100 +SE*100, 
                         group = Population),
                     col = "black", position = position_dodge(width = 0.6))+
      facet_grid(Type_driver_A +
                   Type_eff_A  ~ 
                   model)+
      ylim(0, 100)+
      labs(x = "Fitness",
           y = "Probability of resistance (%)",
           fill = "Resistant\nsubpopulation") +
      scale_fill_manual(values = c( "gray", col_order), drop = F, labels = c("Any",
                                                                             expression(R[A]),
                                                                             expression(R[B]),
                                                                             expression(R[AB])))+
      theme_CS_clean()
    
    return(res_plot)


  }else if(R == "CS"){
    
    df_select<- df %>% 
      filter(time == 336 & Population != "S" & v_FIT == 1)
    

df_plot <- Any_fun(df_select) %>% 
  #filter( model != "Mono A") %>% 
  mutate(v_FIT = 100 - v_FIT*100,
         CS = 100 - CS_A*100) 

levels(df_plot$Population)[1] <- levels(df_plot$Population)[5]
   
res_plot<- ggplot(df_plot[df_plot$Population != "Any",], 
                  aes( x = paste0(CS, "%"), 
                       y = R_Dev*100/n,
                       fill = Population))  +
  geom_col(data = df_plot[df_plot$Population == "Any",],  
           alpha = 0.7, width = 0.6)+
  geom_col(aes(group = Population),
           col = "black", position = "dodge", width = 0.6)+
  geom_linerange(data = df_plot[df_plot$Population == "Any",], 
                 aes(ymin = p*100 - SE*100,
                     ymax = p*100 +SE*100))+
  geom_linerange(aes(ymin = p*100 - SE*100,
                     ymax = p*100 +SE*100, 
                     group = Population),
                 col = "black", position = position_dodge(width = 0.6))+
  facet_grid(Type_driver_A+
               Type_eff_A   ~ 
               model)+
  ylim(0, 100)+
  labs(x = "Magnitude of CS MIC reduction",
       y = "Probability of resistance (%)",
       fill = "Resistant\nsubpopulation")+
  scale_fill_manual(values = c( "gray",  col_order), drop = F, labels = c("Any",
                                                                          expression(R[A]),
                                                                          expression(R[B]),
                                                                          expression(R[AB])))+
  theme_CS_clean()

  }else if(R == "CS vs CS"){
    
    df_select<- df %>% 
      filter(time == 336 & Population != "S" & v_FIT == 1)
    
    
    df_plot <- Any_fun(df_select) %>% 
      filter( model != "Mono A") %>% 
      mutate(v_FIT = 100 - v_FIT*100,
             CS_A = 100 - CS_A*100,
             CS_B = 100 - CS_B*100) 
    
    levels(df_plot$Population)[1] <- levels(df_plot$Population)[5]
    
    res_plot<- ggplot(df_plot[df_plot$Population != "Any",], 
                      aes( x = model, 
                           y = p*100,
                           fill = Population))  +
      geom_col(data = df_plot[df_plot$Population == "Any",],  
               alpha = 0.7, width = 0.6)+
      geom_col(aes(group = Population),
               col = "black", position = "dodge", width = 0.6)+
      geom_linerange(data = df_plot[df_plot$Population == "Any",], 
                     aes(ymin = p*100 - SE*100,
                         ymax = p*100 +SE*100))+
      geom_linerange(aes(ymin = p*100 - SE*100,
                         ymax = p*100 +SE*100, 
                         group = Population),
                     col = "black", position = position_dodge(width = 0.6))+
      facet_grid(Type_driver_A +
                   Type_eff_A + paste0("CS A ", CS_A, "%")  ~ 
                   paste0("CS B ", CS_B, "%"))+
      ylim(0, 100)+
      labs(x = "Dosing schedule",
           y = "Probability of resistance (%)",
           fill = "Resistant\nsubpopulation")+
      scale_fill_manual(values = c( "gray",  col_order) , drop = F, labels = c("Any",
                                                                             expression(R[A]),
                                                                             expression(R[B]),
                                                                             expression(R[AB])))+
      theme_CS_clean()


    
    return(res_plot)   }else if(R == "WT"){
      
      df_select<- df %>% 
        filter(time == 336 & v_FIT == 1)
      
      
      df_plot <- Any_fun(df_select) %>% 
        filter( model != "Mono A") %>% 
        mutate(v_FIT = 100 - v_FIT*100,
               CS = 100 - CS_A*100) 
      
      res_plot<- ggplot(df_plot[df_plot$Population != "Any",], 
                        aes( x = paste0(CS, "%"), 
                             y = R_Dev*100/n,
                             fill = Population))  +
        geom_col(data = df_plot[df_plot$Population == "Any",],  
                 alpha = 0.7, width = 0.6)+
        geom_col(aes(group = Population),
                 col = "black", position = "dodge", width = 0.6)+
        geom_linerange(data = df_plot[df_plot$Population == "Any",], 
                       aes(ymin = p*100 - SE*100,
                           ymax = p*100 +SE*100))+
        geom_linerange(aes(ymin = p*100 - SE*100,
                           ymax = p*100 +SE*100, 
                           group = Population),
                       col = "black", position = position_dodge(width = 0.6))+
        facet_grid(Type_driver_A+
                     Type_eff_A   ~ 
                     model)+
        ylim(0, 100)+
        labs(x = "Magnitude of CS MIC reduction",
             y = "Probability (%)",
             fill = "Subpopulation")+
        scale_fill_manual(values = c(   "black", col_order, "gray") , drop = F)+
        theme_CS_clean()

}else {print("model or CS not correctly specified") }
  
  
}




make_line_plot <- function(df, pop = "Any", type = "line", col_order = c( "#1E88E5", "#FFC107",  "#BE1908")) {
  
  df_select<- df %>% 
    filter(time == 336 & Population != "S" )
  


  df_plot <- Any_fun(df_select) 
  
  if(type == "line"){
fit_plot<- df_plot %>% 
  filter(Population == pop & model != "Mono A") %>% 
  mutate(v_FIT = 100 - v_FIT*100,
         CS = 100 - CS_A*100) %>% 
  ggplot(aes( x = paste0( v_FIT, "%"),
                       y = R_Dev*100/n,
                       col = paste0(CS, "%")))  +

  geom_line(aes(group = CS), size = 1)+
  facet_grid(paste("Gmin =", GMIN_A) +
               paste("Hill= ", HILL_A)  ~
               model)+

  ylim(0, 100)+
  labs(x = "Fitness cost per mutation",
       y = "Probability of\nresistance (%)",
       col = "Magnitude of CS\nMIC reduction") +
  scale_fill_manual(values = c( "gray", col_order), drop = F)+
  theme_CS_clean()

return(fit_plot)

}else if(type == "se"){
  
  
  fit_plot<- df_plot %>% 
    filter(Population == pop & model != "Mono A") %>% 
    mutate(v_FIT = 100 - v_FIT*100,
           CS = 100 - CS_A*100) %>% 
    ggplot(aes( x =  v_FIT,
                y = R_Dev*100/n,
                col = Population,
                alpha = paste0(CS, "%")))  +
    
    geom_line(aes(group = CS, linetype = paste0(CS, "%")), size = 1)+
    geom_linerange(aes(ymin = R_Dev*100/n - SE*100, 
                       ymax = R_Dev*100/n + SE*100, 
                       group = CS))+
    facet_grid(Type_driver_A+ 
                 Type_eff_A ~
                 model)+
    
    ylim(0, 100)+
    labs(x = "Fitness cost per mutation (%)",
         y = "Probability of\nresistance (%)",
         linetype = "Magnitude of CS\nMIC reduction",
         alpha = "Magnitude of CS\nMIC reduction") +
    scale_alpha_manual(values = c(1,  0.5, 0.3))+
    theme_CS_clean()
  
  return(fit_plot)
  
  
}else if(type == "se coen"){
  
  
  fit_plot<- df_plot %>% 
    filter(Population == pop & model != "Mono A") %>% 
    mutate(v_FIT = 100 - v_FIT*100,
           CS = 100 - CS_A*100) %>% 
    ggplot(aes( x =  v_FIT,
                y = R_Dev*100/n))  +
    
    geom_line(aes(group = CS, linetype = paste0(CS, "%"),
                  col = paste0(CS, "%")), size = 1,alpha = 0.7)+
    geom_linerange(aes(ymin = R_Dev*100/n - SE*100, 
                       ymax = R_Dev*100/n + SE*100, 
                       group = CS))+
    facet_grid(Type_driver_A+ 
                 Type_eff_A ~
                 model)+
    
    ylim(0, 100)+
    labs(x = "Fitness cost (%)",
         y = "Probability of resistance (%)",
         linetype = "Magnitude of CS\nMIC reduction",
         col = "Magnitude of CS\nMIC reduction") +
    scale_color_manual(values = c("black", "green4", "green2"))+
    theme_CS_clean_2()
  
  return(fit_plot)
  
  
  
}else if(type == "Css"){
   df_plot <- plot_dat %>% 
     filter(v_Css > 1)
  css_plot<- df_plot %>% 
    filter(model != "Mono A") %>% 
    mutate(CS = 100 - CS_A*100) %>% 
    ggplot(aes( x =  v_Css,
                y = R_Dev*100/n,
                alpha = paste0(CS, "%")))  +
    
    geom_line(aes(group = CS, linetype = paste0(CS, "%")), size = 1)+
    geom_linerange(aes(ymin = R_Dev*100/n - SE*100, 
                       ymax = R_Dev*100/n + SE*100, 
                       group = CS))+
    facet_grid(Type_driver_A+ 
                 Type_eff_A ~
                 model)+
    
    ylim(0, 100)+
    labs(x = "Css x MIC WT",
         y = "Probability of\nresistance (%)",
         linetype = "Magnitude of CS\nMIC reduction",
         alpha = "Magnitude of CS\nMIC reduction") +
    scale_alpha_manual(values = c(1,  0.5, 0.3))+
    theme_CS_clean()
  
  return(css_plot)
  
  

  
  
  
  
}else if(type == "CI"){
  

  
  fit_plot<- df_plot %>% 
    filter(Population == pop & model != "Mono A") %>% 
    mutate(v_FIT = 100 - v_FIT*100,
           CS = 100 - CS_A*100) %>% 
    ggplot(aes( x = paste0( v_FIT, "%"),
                y = R_Dev*100/n))  +
    
    geom_line(aes(group = CS, col = paste0(CS, "%")), size = 1)+
    geom_ribbon(aes(ymin = R_Dev*100/n - CI*100, 
                       ymax = R_Dev*100/n + CI*100, 
                       group = CS, 
                    fill = paste0(CS, "%")), alpha = 0.1)+
    facet_grid(paste("Gmin =", GMIN_A) +
                 paste("Hill= ", HILL_A)  ~
                 model)+
    
    #ylim(0, 100)+
    labs(x = "Fitness cost per mutation",
         y = "Probability of\nresistance (%)",
         col = "Magnitude of CS\nMIC reduction",
         fill = "Magnitude of CS\nMIC reduction") +
    theme_CS_clean()
  
  return(fit_plot)
  
} else{ print("incorrect type specification")
  }
}



#PK plot function

make_PK_plot <- function(df){
  
  df_plot <- df %>% 
    distinct(Population, time, model, .keep_all = T)
  

  plot_PK<- ggplot(df_plot, aes(x = time))+
    geom_line( aes(y = A,  col = "A"))+
    geom_line( aes(y = B,  col = "B"))+
    facet_grid(~model)+
    scale_linetype_manual(values = "dashed")+
    labs(x = "Time (hours)",
         y = "Drug concentartion (mg/L)",
         col = "Drug")+
    theme_CS() 
  
  
  return(plot_PK)
}
